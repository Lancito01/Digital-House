package ExamenParcial;

public interface Comparable {
    public int compareTo(MotorNafta motor);
}
